<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Hanging Man</title>
        <meta charset="utf-8"/>
        <link href="hang.css" rel="stylesheet" type="text/css" />
        <link rel="icon" href="icon.jpg" type="image/gif" sizes="16x16">
        <link href="https://fontmeme.com/super-mario-font/">
        <link href="https://fonts.googleapis.com/css2?family=Henny+Penny&display=swap" rel="stylesheet">   
    </head>
    <body>
        <img src="https://fontmeme.com/permalink/201028/7e9899ab214738bc769592ed3fba2b76.png" alt="super-mario-font" border="0">